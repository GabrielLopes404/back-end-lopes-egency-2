# Configuração de CORS para Deploy no Render

## Importante: Adicione CORS ao seu backend

Para que o frontend hospedado no Vercel consiga fazer requisições ao backend no Render, você precisa adicionar CORS.

### Opção 1: Usando o arquivo cors-config.ts (Recomendado)

Já incluímos o arquivo `server/cors-config.ts`. Adicione ao `server/app.ts`:

```typescript
// No topo do arquivo server/app.ts, adicione:
import cors from 'cors';
import helmet from 'helmet';
import { corsOptions } from './cors-config';

// Depois de criar o app express (linha 24):
export const app = express();

// Adicione estas linhas ANTES de app.use(express.json()):
app.use(helmet());
app.use(cors(corsOptions));

// Resto do código...
```

### Opção 2: CORS simples (se preferir)

Adicione no `server/app.ts` após criar o app:

```typescript
import cors from 'cors';

app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));
```

### Variável de Ambiente no Render

Adicione no Render dashboard:
```
FRONTEND_URL=https://seu-frontend.vercel.app
```

**IMPORTANTE:** Substitua `seu-frontend.vercel.app` pela URL real do seu frontend!

### Testando

Após configurar:
1. Faça deploy do backend no Render
2. Configure `VITE_API_URL` no Vercel com a URL do Render
3. Teste uma requisição da API pelo frontend
4. Se der erro de CORS, verifique os logs do Render

---

💡 **Dica:** O arquivo `cors` já está no package.json como dependência!
