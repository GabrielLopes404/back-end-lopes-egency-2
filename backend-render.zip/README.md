# Lopes Designer - Backend (Render)

Backend Express.js para portfolio profissional - API REST com PostgreSQL.

## 🚀 Deploy no Render

### ⚠️ IMPORTANTE: Configuração Automática

O projeto inclui um arquivo `render.yaml` que configura automaticamente o Render para usar Node.js. Também há um arquivo `.node-version` que especifica a versão do Node.js (20).

### Passo a Passo:

1. **Acesse** [render.com](https://render.com) e faça login

2. **Crie um Web Service:**
   - Clique em "New +" → "Web Service"
   - Conecte seu repositório GitHub/GitLab

3. **Configurações:**
   
   **OPÇÃO A: Deixe o Render detectar automaticamente (Recomendado)**
   - O Render vai detectar o `render.yaml` e configurar tudo automaticamente
   - Você só precisa adicionar as variáveis de ambiente (veja passo 4)
   
   **OPÇÃO B: Configuração Manual**
   - **Name:** `lopes-designer-backend` (ou nome de sua escolha)
   - **Environment:** `Node` (IMPORTANTE: selecione Node, não Elixir)
   - **Region:** Escolha a mais próxima dos seus usuários
   - **Branch:** `main` (ou sua branch principal)
   - **Root Directory:** deixe em branco (arquivo está na raiz)
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
   - **Instance Type:** Free (ou pago se preferir)

4. **Variáveis de Ambiente:**
   Adicione as seguintes variáveis em "Environment Variables":
   
   ```
   NODE_ENV=production
   PORT=5000
   FRONTEND_URL=https://seu-frontend.vercel.app
   ```

   **Opcional (se usar banco de dados):**
   ```
   DATABASE_URL=sua_url_do_postgres
   SESSION_SECRET=um_segredo_aleatorio_forte
   ```

5. **Clique** em "Create Web Service"

6. **Aguarde** o deploy (pode levar alguns minutos)

7. **Copie a URL** do seu backend (ex: `https://lopes-designer-backend.onrender.com`)

8. **IMPORTANTE:** Use essa URL como `VITE_API_URL` no frontend!

## 🗄️ Banco de Dados PostgreSQL (Opcional)

### Opção 1: Usar o PostgreSQL do Render

1. No dashboard do Render, clique em "New +" → "PostgreSQL"
2. Configure o banco
3. Copie a "External Database URL"
4. Adicione como variável de ambiente `DATABASE_URL` no seu Web Service

### Opção 2: Usar Neon, Supabase ou outro provedor

1. Crie um banco PostgreSQL no provedor de sua escolha
2. Copie a connection string
3. Adicione como variável `DATABASE_URL`

### Executar Migrações

```bash
# Local
npm run db:push

# No Render, adicione ao Build Command:
npm install && npm run db:push && npm run build
```

## 🛠️ Desenvolvimento Local

```bash
# Instalar dependências
npm install

# Criar arquivo .env
cat > .env << EOF
NODE_ENV=development
PORT=5000
FRONTEND_URL=http://localhost:3000
DATABASE_URL=postgresql://user:password@localhost:5432/dbname
SESSION_SECRET=seu_segredo_local
EOF

# Rodar servidor de desenvolvimento
npm run dev

# Build para produção
npm run build

# Rodar em modo produção
npm start
```

## 📁 Estrutura do Projeto

```
backend-render/
├── server/
│   ├── app.ts           # Configuração Express
│   ├── routes.ts        # Rotas da API
│   ├── storage.ts       # Lógica de dados
│   ├── index-dev.ts     # Server desenvolvimento
│   └── index-prod.ts    # Server produção
├── shared/              # Tipos TypeScript compartilhados
├── data/                # Dados JSON estáticos
└── drizzle.config.ts    # Configuração Drizzle ORM
```

## 🎯 Endpoints da API

```
GET /api/portfolio        # Lista itens do portfolio
GET /api/services         # Lista serviços
GET /api/testimonials     # Lista depoimentos
GET /api/faqs            # Lista perguntas frequentes
GET /api/before-after    # Lista comparações antes/depois
```

## 🔒 CORS e Segurança

O backend está configurado para aceitar requisições apenas do frontend especificado em `FRONTEND_URL`.

Para adicionar mais origens permitidas, edite o arquivo `server/app.ts`:

```typescript
// Adicione helmet para segurança
import helmet from 'helmet';
import cors from 'cors';

app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));
```

## 🔧 Scripts Disponíveis

- `npm run dev` - Servidor desenvolvimento com hot reload
- `npm run build` - Build para produção
- `npm start` - Inicia servidor em produção
- `npm run check` - Verifica tipos TypeScript
- `npm run db:push` - Aplica schema do banco de dados

## ⚡ Performance no Render (Tier Gratuito)

O tier gratuito do Render hiberna após 15 minutos de inatividade:
- Primeira requisição após hibernação pode levar 30-60 segundos
- Para evitar isso, considere:
  - Upgrade para plano pago ($7/mês)
  - Usar um serviço de ping (como UptimeRobot)

## 🐛 Solução de Problemas

### ❌ Erro: "Using Erlang/Elixir" ou "Could not read package.json"

**Sintoma:** O Render tenta usar Erlang/Elixir em vez de Node.js e aparece:
```
npm error path /opt/render/project/src/package.json
npm error enoent Could not read package.json
```

**Solução:**
1. ✅ O projeto já inclui `render.yaml` e `.node-version` para evitar isso
2. ✅ Se o erro persistir, na configuração do Render:
   - Vá em "Settings" → "Environment"
   - Selecione **"Node"** (não Elixir)
   - Salve e faça redeploy manual
3. ✅ Confirme que o `package.json` está na raiz do repositório
4. ✅ Delete o serviço e crie novamente se necessário

### Erro de CORS
1. Verifique se `FRONTEND_URL` está correta nas variáveis de ambiente
2. Certifique-se de incluir o protocolo (`https://`)
3. Não inclua barra no final da URL

### Erro 503 Service Unavailable
- O serviço está hibernando (tier gratuito)
- Aguarde 30-60 segundos e tente novamente

### Build falha
1. Verifique se todas as dependências estão no `package.json`
2. Confirme que o comando de build está correto
3. Veja os logs no Render dashboard

### Banco de dados não conecta
1. Verifique se `DATABASE_URL` está configurada
2. Confirme que o banco está acessível externamente
3. Verifique se as credenciais estão corretas

## 📊 Monitoramento

No dashboard do Render você pode:
- Ver logs em tempo real
- Monitorar uso de recursos
- Configurar health checks
- Ver histórico de deploys

## 🔄 Deploy Automático

O Render faz deploy automático sempre que você faz push para a branch configurada.

Para desabilitar:
1. Vá em "Settings"
2. Desmarque "Auto-Deploy"

---

Desenvolvido com 💜 por Lopes Designer
